<?php 
/***
 This is Main class For Plugin.
***/
 

class TeamClass
{

    /* constructor method */
    public function __construct($params= false)
    {
        
    }
	
	
}

 

?>