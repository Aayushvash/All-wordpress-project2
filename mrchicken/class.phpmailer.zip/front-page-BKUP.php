<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header(); ?>

<!-- begin banner -->
<section id="banner-wrap">
<img src="http://mrchickencater.com/wp-content/uploads/2014/03/MarchMadnessBanner.jpg" width="1905" height="787" />
<!--<!-- center block -->
    <article class="center-block">
        
       <h2><?php echo get_theme_option('bannertext'); ?></h2>
		
    </article>
    <!-- center block -->-->
	
	

</section>
<!-- finish banner -->

<?php get_footer(); ?>
